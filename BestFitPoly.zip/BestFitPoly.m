%% Program to find best-fit polynomials
% Ricardo Murphy (ricardo_murphy@fastmail.fm)
% Edinburgh, UK

%% Initialise
clearvars; fclose('all'); close all; 
set(0,'DefaultFigureWindowStyle','docked');
xprednewraw = []; first_min = 'yes'; Fdir = 'backward';
center = 'yes'; maxmaxdeg = 3; heirarchical = 'no'; 
Alpha = 0.05; generator = 'default'; rngseed = 0; 
prt_lme = 0; dir = ''; save_resids = 1; nboot = 2000;
save_boot_effect = 0; save_boot_resids = 'no'; save_boot = 'no'; 
calc_press_boot = 1; calc_press = 1; save_boot_F = 0; 
save_boot_t = 0; save_boot_paras = 0; save_boot_LOF = 0;
save_boot_Fim = 0; sxeffect = 'maxeffect'; const_var = 'no';

%% Load configuration data
f = fopen('BestFitPoly_Config.txt', 'r');
while ~feof(f)
    tline = fgetl(f); option = split(tline,':');
    option{2} = strtrim(option{2});
    if contains(option{1},'Data folder/directory')
        nd = size(option);
        if nd(1) == 2
            dir = option{2};
        else
            dir = strcat(option{2},':',option{3});
        end
        dir = strcat(dir,'/');
    end
    if contains(option{1},'Data text file name')
        filename = option{2};
    end
    if contains(option{1},'New x values')
        option{2} = strip(option{2});
        if strlength(option{2}) > 0
            if contains(option{2},',')
                xs = split(option{2},','); 
            else
                xs = split(option{2}); 
            end
            nxs = size(xs);
            xprednewraw = zeros(nxs(1),1);
            for i = 1:nxs(1)
                xprednewraw(i) = str2double(xs(i));
            end
        end
    end
    if contains(option{1},'Center the x data')
        center = option{2};
    end
    if contains(option{1},'Maximum polynomial degree')
        maxmaxdeg = str2double(option{2});
    end
    if contains(option{1},'Hierarchical polynomial fitting')
        heirarchical = option{2};
    end
    if contains(option{1},'Always choose the minimum-parameter best-fit model')
        first_min = option{2};
    end
    if contains(option{1},'Critical level of significance (alpha)')
        Alpha = str2double(option{2});
    end
    if contains(option{1},'Print model-fitting details to screen and ...printout.txt')
        if strcmp(option{2}, 'yes')
            prt_lme = 1; diary(strcat(dir,filename,'_printout.txt'));
        else
            prt_lme = 0; diary off;
        end
    end
    if contains(option{1},'Compute t values based on parameters or maxeffect')
        sxeffect = option{2};
    end
    if contains(option{1},'Direction of F-to-enter search')
        Fdir = option{2};
    end
    if contains(option{1},'Critical F-to-enter value')
        Fcrit = str2double(option{2});
    end
    if contains(option{1},'Save model fitted values and residuals')
        if strcmp(option{2}, 'no'), save_resids = 0; end
    end
    if contains(option{1},'Number of bootstrap samples')
        nboot = str2double(option{2});
    end
    if contains(option{1},'Constant variance')
        const_var = option{2};
    end
    if contains(option{1},'Save bootstrapped parameters and predictions')
        if strcmp(option{2}, 'yes'), save_boot_paras = 1; end
    end
    if contains(option{1},'Save bootstrapped residuals')
        save_boot_resids = option{2};
    end
    if contains(option{1},'Save bootstrapped test statistics')
        save_boot = option{2};
    end
    if contains(option{1},'Random number generator')
        generator = option{2};
    end
    if contains(option{1},'RNG seed')
        rngseed = str2double(option{2});
    end
end
fclose(f);
if strcmp(save_boot,'yes')
    save_boot_F = 1; save_boot_t = 1; 
    save_boot_LOF = 1; save_boot_Fim = 1;
end
CL = num2str(100*(1-Alpha));

%% Set some file names
fn = strcat(dir,filename);
heirarch = "_"; smxd = string(maxmaxdeg); 
if strcmp(heirarchical,'yes'), heirarch = "_heirarchical_"; end
fo = fn+heirarch+"polynomial-"+smxd+"_analysis.txt";
fm = fn+heirarch+"polynomial-"+smxd+"_models.txt";
fresn = fn+heirarch+"polynomial-"+smxd+"_resids_model-";
plotfn = fn+heirarch+"polynomial-"+smxd+"_model-";
plotfullfn = fn+"_full_model";
if nboot > 0
    fbrn = fn+heirarch+"polynomial-"+smxd+"_boot-resids.txt";
    fbn = fn+heirarch+"polynomial-"+smxd+"_boot-F.txt";
    tbn = fn+heirarch+"polynomial-"+smxd+"_boot-t.txt";
    ebn = fn+heirarch+"polynomial-"+smxd+"_boot-effect.txt";
    lofbn = fn+heirarch+"polynomial-"+smxd+"_boot-LOF.txt";
    fbFimn = fn+heirarch+"polynomial-"+smxd+"_boot-F_model.txt";
    datafn = fn+heirarch+"polynomial-"+smxd+"_boot-";
    datafullfn = fn+"_full_model_boot-";
    fbFfullfn = fn+"_full_model_boot-F.txt";
end
fn = fn+".txt";

%% Random number generator
if rngseed < 0
    if strcmp(generator,'default')
        rng('default');
        rng('shuffle');
    else
        rng('shuffle',generator); 
    end
else
    if strcmp(generator,'default')
        rng('default');
        rng(rngseed);
    else
        rng(rngseed,generator);
    end
end

tic
%% Load data from file and set up treatment groups
f = fopen(fn, 'r'); tline = fgetl(f); fclose(f); delim = '\t';
if contains(tline,',')
    xyn = strsplit(tline,','); delim = ',';
elseif contains(tline,'\t')
    tline = strip(tline,'\t'); xyn = strsplit(tline,'\t');
else
    tline = strip(tline); xyn = strsplit(tline);  delim = '';
end
xn = xyn{1}; yn = xyn{2};
M = dlmread(fn,delim,1,0); n = size(M); n = n(1);
x =  M(:,1); y = M(:,2); mean_x = mean(x); xraw = x;
xy = table(x,y); grps = grpstats(xy,'x'); grpraw = grps.(1); 
if strcmp(center, 'yes')
    x = x - mean_x;
end
subject = zeros(n,1);
for i = 1:n
    subject(i) = i;
end
xeffect0 = x(1);
xy = table(x,y,subject);
grps = grpstats(xy,'x'); 
grp = grps.(1); grpsize = grps.(2); 
ngrp = size(grp); ngrp = ngrp(1); doLOF = 0;
if ngrp > 2
    for i = 1:ngrp
        if grpsize(i) > 2
            doLOF = 1; break;
        end
    end
end
xgrp = x; xx = xgrp(1); ix = 1;
for i = 1:n
    if xgrp(i) > xx
        xx = xgrp(i);
        ix = ix + 1;
    end
    xgrp(i) = ix;
end
xpredraw = grpraw; xpred = grpraw; xprednew = xprednewraw;
if strcmp(center, 'yes'), xpred = xpred - mean_x; end
if strcmp(center, 'yes'), xprednew = xprednew - mean_x; end
nxpred = size(xpred); nxpred = nxpred(1);
nxprednew = size(xprednew); nxprednew = nxprednew(1);

%% Set up polynomial models
model = {[1,1]}; modeq = {[1,1]};
model{1} = 'y ~ 1'; modeq{1} = 'y = b0';
maxdeg = ngrp-1; 
if maxdeg > maxmaxdeg, maxdeg = maxmaxdeg; end
if maxdeg < maxmaxdeg
    fprintf('Only %d groups: reducing maximum degree to %d\r',ngrp,maxdeg)
end
deg = [1:maxdeg]; ii = 1;
for k = 1:maxdeg
    if strcmp(heirarchical,'yes')
        C = [1:k];
    else
        C = combnk(deg,k);
    end
    ndeg = size(C);
    for j = 1:ndeg(1)
        ii = ii + 1;
        modeq{ii} = 'y = b0';
        model{ii} = 'y ~ 1 ';
        for i = 1: ndeg(2)
            s = char(string(C(j,i)));
            modeq{ii} = strcat( modeq{ii},' + b',s,'*x');
            model{ii} = strcat(model{ii},' + x');      
            if C(j,i) > 1
                modeq{ii} = strcat(modeq{ii},'^',s);
                for jj = 1:C(j,i)-1
                    model{ii} = strcat(model{ii},':x');
                end
            end
        end
    end
end
ii = 1;
for k = 1:maxdeg
    if strcmp(heirarchical,'yes')
        C = [1:k];
    else
        C = combnk(deg,k);
    end
    ndeg = size(C);
    for j = 1:ndeg(1)
        ii = ii + 1;
    end
end

%% Get maximum string length for models
nm = size(modeq); nm = nm(2); nsmax = 0;  
for i = 1:nm
    ns = size(modeq{i}); 
    ns = ns(2);
    if ns > nsmax
        nsmax = ns;
    end
end
ns = nsmax + 3;

%% Find best fit models
[np,df,rss,mse,press,bic,aic,DF1,DF2,F,pValF,yeffect,sef,tVal,pValt] = ...
    fit_lme(nm,model,modeq,x,y,subject,calc_press,prt_lme,xeffect0,sxeffect);
im_mse = best_model(nm,np,mse,first_min); Fmse = F(im_mse); tmse = tVal(im_mse);
im_aic = best_model(nm,np,aic,first_min); Faic = F(im_aic); taic = tVal(im_aic);
im_bic = best_model(nm,np,bic,first_min); Fbic = F(im_bic); tbic = tVal(im_bic);
if calc_press == 1
    im_press = best_model(nm,np,press,first_min);
    Fpress = F(im_press); tpress = tVal(im_press);
end
DF = DF2; npara = np;
f = fopen(fo, 'w');
fprintf(f,'Analysis of data in %s:\n', fn);
if strcmp(center, 'yes')
    fprintf(f,'x: %s  (centered: mean(x) = %g)\n', xn,mean_x);
else
    fprintf(f,'x: %s\n', xn);
end
fprintf(f,'y: %s\n', yn);
if nxprednew > 0
    fprintf(f,'New predictions for x values: ');
    for i = 1:nxprednew
       fprintf(f,'%g  ',xprednewraw(i));
    end
    fprintf(f,'\n');
end
if maxdeg < maxmaxdeg
    fprintf(f,'Only %d groups: the maximum degree is reduced from %d to %d\n',ngrp,maxmaxdeg,maxdeg);
end
fprintf(f,'\n');
savef = f;
if nm > 20
    fprintf(f,'Model details saved to %s\n',fm);
    fprintf(f,'\n'); ff = fopen(fm, 'w'); f = ff;
end
if strcmp(heirarchical,'yes')
    fprintf(f,'Heirarchical polynomial models with m fixed effects parameters:\n');
else
    fprintf(f,'Polynomial models with m fixed effects parameters:\n');
end
fprintf(f,'%3s%'+string(ns)+'s%5s\n','#','Model','m');
for i = 1:nm
    fprintf(f,'%3d%'+string(ns)+'s%5d\n',i,string(modeq(i)),np(i));
end
fprintf(f,'\n');
if calc_press == 1
    fprintf(f,'Best-fit model(s) according to MSE, AIC, BIC and PRESS:\n');
    fprintf(f,'%3s%5s%8s%15s%15s%15s%15s%15s\n','#','m','DFE','SSE','MSE','AIC','BIC','PRESS');
else
    fprintf(f,'Best-fit model(s) according to MSE, AIC and BIC:\n');
    fprintf(f,'%3s%5s%8s%15s%15s%15s%15s\n','#','m','DFE','SSE','MSE','AIC','BIC');            
end
for i = 1:nm
    fprintf(f,'%3d%5d%8d%15.5e',i,np(i),df(i),rss(i));
    fprintf(f,'%15.5e',mse(i));
    fmt_aic = this_one(f,im_mse,i,1,0);
    fprintf(f,fmt_aic,aic(i));
    fmt_bic = this_one(f,im_aic,i,1,0);
    fprintf(f,fmt_bic,bic(i));
    fmt_press = this_one(f,im_bic,i,1,0);
    if calc_press == 1
        fprintf(f,fmt_press,press(i));
        this_one(f,im_press,i,1,1);
    else
        fprintf(f,'\n');
    end
end
fprintf(f,'\n');

if strcmp(Fdir,'forward')
    [im_Fe,np_Fe,FFe,i0,Fm,nF] =  F_to_enter_fwrd(nm,np,DF2,F,rss,mse,Fcrit);
else
    [im_Fe,np_Fe,FFe,i0,Fm,nF] =  F_to_enter_back(nm,np,DF2,F,rss,mse,Fcrit);
end
tFe = tVal(im_Fe);
fprintf(f,'Best model according to F-to-enter = %3.1f:\n',Fcrit);
fprintf(f,'%3s%5s%7s%10s\n', '#','m','DFE','F');
for i = 1:nF
    fprintf(f,'%3d%5d%7d%10.2f', i0(i),np_Fe(i),df(i0(i)),Fm(i)');
    this_one(f,im_Fe,i0(i),1,1);
end
if nm > 20, fclose(ff); end
f = savef; 

imu = [];
imu = horzcat(imu,im_mse); 
imu = horzcat(imu,im_aic); 
imu = horzcat(imu,im_bic); 
if calc_press == 1
    imu = horzcat(imu,im_press);
end
imu = horzcat(imu,im_Fe);
fprintf(f,'\n');
nmu = size(imu); nmu = nmu(2);
if nmu > 0
    imu = unique(imu); nmu = size(imu); nmu = nmu(2);
end
if nmu == 0
    imu = 1; nmu = 1;
end
if nmu > 1
    fprintf(f,'Candidate models are: ');
else
    fprintf(f,'Candidate model is: ');
end
for i = 1:nmu
    fprintf(f,'%d ', imu(i));
end
fprintf(f,'\n'); fprintf(f,'\n'); fprintf(f,'\n');

fprintf(f,'*************************** NORMAL ERROR MODEL ***************************\n');
fprintf(f,'\n');
%F and t tests
fprintf(f,'Best models: F and t tests (nominal p values under the normal error model).\n');
fprintf(f,'p(F), p(t)I: probabilities of a Type I Error (false positive) under the NH y = b0.\n');
fprintf(f,'p(t)III: probability of a Type III Error (true effect is opposite to that observed).\n');
effect_text(f,xeffect0,sxeffect);
fprintf(f,'Criterion %3s%5s%5s%8s%10s%15s%15s%8s%10s%10s\n', '#','m','DFE','F','p(F)','Effect','SE','t','p(t)I','p(t)III');
fprintf(f,'     MSE: %3d%5d%5d%8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', im_mse, np(im_mse), df(im_mse), Fmse, pValF(im_mse), yeffect(im_mse), sef(im_mse), tVal(im_mse), pValt(im_mse), 0.5*pValt(im_mse));
fprintf(f,'     AIC: %3d%5d%5d%8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', im_aic, np(im_aic), df(im_aic), Faic, pValF(im_aic), yeffect(im_aic), sef(im_aic), tVal(im_aic), pValt(im_aic), 0.5*pValt(im_aic));
fprintf(f,'     BIC: %3d%5d%5d%8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', im_bic, np(im_bic), df(im_bic), Fbic, pValF(im_bic), yeffect(im_bic), sef(im_bic), tVal(im_bic), pValt(im_bic), 0.5*pValt(im_bic));
if calc_press == 1
    fprintf(f,'   PRESS: %3d%5d%5d%8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', im_press, np(im_press), df(im_press), Fpress, pValF(im_press), yeffect(im_press), sef(im_press), tVal(im_press), pValt(im_press), 0.5*pValt(im_press));
end
fprintf(f,'   F>%3.1f: %3d%5d%5d%8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Fcrit, im_Fe, np(im_Fe), df(im_Fe), FFe, pValF(im_Fe), yeffect(im_Fe), sef(im_Fe), tVal(im_Fe), pValt(im_Fe), 0.5*pValt(im_Fe));
fprintf(f,'\n');
SD = zeros(nmu,1);
SDb1 = -ones(nmu,1);

%% Preliminaries for lack of fit (LOF) tests
Flof = zeros(nmu); Fim = zeros(nmu);
xgrp = x; xx = xgrp(1); ix = 1; 
for i = 1:n
    if xgrp(i) > xx
        xx = xgrp(i);
        ix = ix + 1;
    end
    xgrp(i) = ix;
end
Dfull = dummyvar(xgrp); nD = size(Dfull);
fullmodel = 'y ~ -1'; vn = {'y'};
for i = 1:nD(2)
    vn{i+1} = char(strcat('x',string(i)));
    fullmodel = char(strcat(fullmodel,' + x',string(i)));
end

%% Some more preliminaries.
npmax = max(np(imu)); err = zeros(nmu,1); nplot = 1000;
xplot = zeros(nplot,1); subjplot = zeros(nplot,1);
betaim = zeros(nmu,npmax); betan = string(betaim);
muhat = zeros(nxpred,nmu); muhatnew = zeros(nxprednew,nmu);
effect = zeros(nxpred,nmu); effectnew = zeros(nxprednew,nmu);
fmt = string([1,nmu]); fig = cell(nmu,1);
xmin = min(grpraw); xmax = max(grpraw); dx = (xmax-xmin)/(nplot-1);
for i = 1:nplot
    xplot(i) = xmin + (i-1)*dx;
end
xcalc = xplot;
if strcmp(center, "yes"), xcalc = xplot  - mean_x; end

%% Then for each of the nmu best-fit models:
for k = 1:nmu
    %% F test and LOF test
    im = imu(k); fprintf(f,'\n');
    fprintf(f,'MODEL %d: %s\n', im, modeq{im}); fprintf(f,'\n');
    xy = xytable(x,y,subject);
    lm = fitlm(xy,model{im});
    npv = lm.NumEstimatedCoefficients;
    dfl = lm.NumObservations - npv;
    if im > 1
        H = zeros(npv-1,npv);
        C = zeros(npv-1,1);
        for j = 1:npv-1
            H(j,j+1) = 1;
        end
        [pFim,Fim(k),dfu] = coefTest(lm,H,C);                
    else
        Fim(k) = 0;
    end
    if Fim(k) == 0
        fprintf(f,'Constant model: no F test\n');
    else
        fprintf(f,'Nominal F test: F(%d,%d) = %7.3f, p(F) = %7.5f\n', dfu,dfl,Fim(k),pFim);
    end
    fprintf(f,'\n');
    [Flof(k), dfu, dfl, pFlof] = LOF(x,y,subject,model{imu(k)},Dfull,fullmodel,vn);
    if Flof(k) == 0
        fprintf(f,'Full model: no lack of fit test\n');
    else
        fprintf(f,'Nominal lack of fit test: F(%d,%d) = %7.3f, p(F) = %7.5f\n', dfu,dfl,Flof(k),pFlof);
    end
    fprintf(f,'\n');

    %% Parameter estimates    
    fprintf(f,'Parameter estimates and %s%% confidence limits for model %d:\n', CL,im);
    beta = lm.Coefficients.Estimate;
    betanames = lm.CoefficientNames';
    stats = lm.Coefficients;
    ci = coefCI(lm,Alpha);
    Cov = lm.CoefficientCovariance; 
    yhat = lm.Fitted;
    rawres = lm.Residuals.Raw;
    stares = lm.Residuals.Standardized;
    stures = lm.Residuals.Studentized;
    linmod = lm; err(k) = lm.SSE/n; sumsq = 0;
    for i = 1:n
        ypred = predict(lm,table(x(i),'VariableNames',{'x'}));
        for j = 1:n
            dy = y(j) - ypred;
            sumsq = sumsq + dy*dy;
        end
    end
    [~,ciplot] = predict(lm,table(xcalc,'VariableNames',{'x'}),'Alpha',Alpha);
    [yplot,piplot] = predict(lm,table(xcalc,'VariableNames',{'x'}),'Prediction','observation','Alpha',Alpha);
    npv = size(beta);
    fmt(k) = "%9s";
    fprintf(f,fmt(k)+'%15s%15s%15s\n','Parameter','Estimate','SE','tStat');
    for i = 1:npv(1)  
        betaim(k,i) = beta(i);
        betan(k,i) = betanames{i,1};
        if i == 1
            fprintf(f,'%9s','b0');
        elseif ~contains(betanames{i,1},'^')
            fprintf(f,'%9s','b1');
        else
            bp = strsplit(string(betanames{i,1}),'^');
            fprintf(f,'%9s','b'+bp(2));
        end
        fprintf(f,'%15g',beta(i));
        fprintf(f,'%15g',stats.SE(i));
        fprintf(f,'%15g',stats.tStat(i));
        fprintf(f,'\n');
    end
    fprintf(f,'\n');
    fprintf(f,'%9s%15s%15s%15s\n','DF','pValue','Lower','Upper');
    for i = 1:npv(1)
        fprintf(f,'%9g',lm.DFE);
        fprintf(f,'%15g',stats.pValue(i));
        fprintf(f,'%15g',ci(i,1));
        fprintf(f,'%15g',ci(i,2));
        fprintf(f,'\n');
    end

    %% Variance-covariance matrix of parameters    
    ncv = size(Cov); fprintf(f,'\n');
    fprintf(f,'Variance-covariance matrix of parameters:\n');
    for i = 1:ncv(1)
        for j = 1:ncv(2)
            fprintf(f,'%15g',Cov(i,j));
        end
        fprintf(f,'\n');
    end
    fprintf(f,'\n');

    SD(k) = sqrt(lm.MSE);
    X = chi2inv(0.5*Alpha,DF2(im));
    ucl = SD(k)*sqrt(DF2(im)/X);
    X = chi2inv(1-0.5*Alpha,DF2(im));
    lcl = SD(k)*sqrt(DF2(im)/X);
    fprintf(f,'Error SD = sqrt(MSE): %g (%g, %g)\n', SD(k),lcl,ucl);            
    fprintf(f,'\n');

    %% Predicted response and effect size    
    [muhat(:,k),muci,ypi,effect(:,k),mueci,yepi] = polypred(linmod,model(im),xpred,xeffect0,Alpha);
    if nxprednew > 0
        [muhatnew(:,k),mucinew,ypinew,effectnew(:,k),muecinew,yepinew] = polypred(linmod,model(im),xprednew,xeffect0,Alpha);
    end
    fprintf(f,'Predicted response with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
    if strcmp(center,'yes')
        fprintf(f,'%15s%15s','x','x-xbar');
    else
        fprintf(f,'%15s','x');
    end
    fprintf(f,'%15s%15s%15s%15s%15s\n','yhat','LowerCL','UpperCL','LowerPL','UpperPL');
    for i = 1:nxpred
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xpredraw(i),xpred(i));
        else
            fprintf(f,'%15g',xpred(i));
        end
        fprintf(f,'%15g%15g%15g%15g%15g\n',muhat(i,k),muci(i,1),muci(i,2),ypi(i,1),ypi(i,2));
    end
    if nxprednew > 0
        for i = 1:nxprednew
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xprednewraw(i),xprednew(i));
            else
                fprintf(f,'%15g',xprednew(i));
            end
            fprintf(f,'%15g%15g%15g%15g%15g\n',muhatnew(i,k),mucinew(i,1),mucinew(i,2),ypinew(i,1),ypinew(i,2));
        end    
    end
    fprintf(f,'\n');
    fprintf(f,'Effect size with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
    if strcmp(center,'yes')
        fprintf(f,'%15s%15s','x','x-xbar');
    else
        fprintf(f,'%15s','x');
    end
    fprintf(f,'%15s%15s%15s%15s%15s\n','Effect','LowerCL','UpperCL','LowerPL','UpperPL');
    for i = 1:nxpred
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xpredraw(i),xpred(i));
        else
            fprintf(f,'%15g',xpred(i));
        end
        fprintf(f,'%15g%15g%15g%15g%15g\n',effect(i,k),mueci(i,1),mueci(i,2),yepi(i,1),yepi(i,2));
    end
    if nxprednew > 0
        for i = 1:nxprednew
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xprednewraw(i),xprednew(i));
            else
                fprintf(f,'%15g',xprednew(i));
            end
            fprintf(f,'%15g%15g%15g%15g%15g\n',effectnew(i,k),muecinew(i,1),muecinew(i,2),yepinew(i,1),yepinew(i,2));  
        end
    end
    fprintf(f,'\n');

    %% Save residuals and fitted values    
    if save_resids == 1
        fres = fopen(fresn+string(im)+".txt", 'w');
        fprintf(fres,'%15s%15s%15s%15s%20s','x','y','yhat','Residual','Standard.Resid.');
        fprintf(fres,'%20s\n','Student.Resid.');
        for i = 1:n
            fprintf(fres,'%15.5e%15.5e%15.5e%15.5e%20.5e',x(i),y(i),yhat(i),rawres(i),stares(i));
            fprintf(fres,'%20.5e\n',stures(i));
        end
        fclose(fres);
    end
    
    %% Plots
    fig{k} = figure('Name',modeq{im}','NumberTitle','off');
    subplot(2,2,1)
    plot(grpraw,grps.(3),'ko'); hold on;
    plot(xplot,yplot,'k-','LineWidth',1.3);
    plot(xplot,ciplot(:,1),'k--','LineWidth',1.0);
    plot(xplot,ciplot(:,2),'k--','LineWidth',1.0);
    xlabel('x'); ylabel('Mean(y)')
    xl(1) = min(xplot); xl(2) = max(xplot);
    yl(1) = min(ciplot(:,1)); yl(2) = max(ciplot(:,2)); 
    xpt = xl(1) + 0.8*(xl(2)-xl(1));
    ypt = yl(1) - 0.3*(yl(2)-yl(1));
    text(xpt,ypt,'(bootstrapped are dotted)')
    title(strcat(sprintf('%g',100*(1-Alpha)),'% confidence intervals'));
    subplot(2,2,2)
    plot(xraw,y,'ko'); hold on;
    plot(xplot,yplot,'k-','LineWidth',1.3);
    plot(xplot,piplot(:,1),'k--','LineWidth',1.0);
    plot(xplot,piplot(:,2),'k--','LineWidth',1.0);
    xlabel('x'); ylabel('y')
    title(strcat(sprintf('%g',100*(1-Alpha)),'% prediction intervals'));
    subplot(2,2,3)
    plot(yhat,rawres,'ko'); hold on;
    xl = xlim; plot([xl(1),xl(2)],[0,0],'k--');
    xlabel('yhat'); ylabel('y - yhat')
    title('Residuals')
    subplot(2,2,4)
    normplot(rawres); xlabel('y - yhat')
    title('Normal plot')
end
fprintf('\n');
fprintf(f,'\n');

%% Full model (gropup means)
xyfull = array2table([y,Dfull],'VariableNames',vn);
lmefull = fitlm(xyfull,fullmodel);
dfu = ngrp - 1; dfl = n - lmefull.NumCoefficients;
Ffull = (lmefull.SST - lmefull.SSE)/(dfu*lmefull.MSE);
pFfull = fcdf(Ffull,dfu,dfl,'upper');
fprintf(f,'FULL MODEL: Group means (probably best for predictions)\n'); fprintf(f,'\n');
fprintf(f,'Nominal F test: F(%d,%d) = %7.3f, p(F) = %7.5f\n', dfu,dfl,Ffull,pFfull);
fprintf(f,'\n');
%% Full model predicted respopnse
xcalc = array2table(eye(ngrp),'VariableNames',vn(2:ngrp+1));
[~,ciplot] = predict(lmefull,xcalc,'Alpha',Alpha);
[yplot,piplot] = predict(lmefull,xcalc,'Prediction','observation','Alpha',Alpha);
fprintf(f,'Predicted response with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
if strcmp(center,'yes')
    fprintf(f,'%15s%15s','x','x-xbar');
else
    fprintf(f,'%15s','x');
end
fprintf(f,'%15s%15s%15s%15s%15s\n','yhat','LowerCL','UpperCL','LowerPL','UpperPL');
for i = 1:nxpred
    if strcmp(center,'yes')
        fprintf(f,'%15g%15g',xpredraw(i),xpred(i));
    else
        fprintf(f,'%15g',xpred(i));
    end
    fprintf(f,'%15g%15g%15g%15g%15g\n',yplot(i),ciplot(i,1),ciplot(i,2),piplot(i,1),piplot(i,2));
end
if nxprednew > 0
    [newy,newci,newpi] = FullModel_pred(xpred,yplot,ciplot,piplot,xprednew);
    for i = 1:nxprednew
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xprednewraw(i),xprednew(i));
        else
            fprintf(f,'%15g',xprednew(i));
        end
        fprintf(f,'%15g%15g%15g%15g%15g\n',newy(i),newci(i,1),newci(i,2),newpi(i,1),newpi(i,2));
    end    
end
fprintf(f,'\n');
%% Full model predicted effect
e = zeros(nxpred); eci = zeros(nxpred); epi = zeros(nxpred);
ci20 = (ciplot(1,2)-ciplot(1,1))^2;
pi20 = (piplot(1,2)-piplot(1,1))^2;
fprintf(f,'Effect size with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
if strcmp(center,'yes')
    fprintf(f,'%15s%15s','x','x-xbar');
else
    fprintf(f,'%15s','x');
end
fprintf(f,'%15s%15s%15s%15s%15s\n','Effect','LowerCL','UpperCL','LowerPL','UpperPL');
for i = 1:nxpred
    if i > 1
        e(i) = yplot(i) - yplot(1);
        ci2 = (ciplot(i,2)-ciplot(i,1))^2;
        dy = 0.5*sqrt(ci2 + ci20);
        eci(i,1) = e(i) - dy; eci(i,2) = e(i) + dy;
    end
    pi2 = (piplot(i,2)-piplot(i,1))^2;
    dy = 0.5*sqrt(pi2 + pi20);
    epi(i,1) = e(i) - dy; epi(i,2) = e(i) + dy;
    if strcmp(center,'yes')
        fprintf(f,'%15g%15g',xpredraw(i),xpred(i));
    else
        fprintf(f,'%15g',xpred(i));
    end
    fprintf(f,'%15g%15g%15g%15g%15g\n',e(i),eci(i,1),eci(i,2),epi(i,1),epi(i,2));
end
if nxprednew > 0
    [newe,newci,newpi] = FullModel_pred(xpred,e,eci,epi,xprednew);
    for i = 1:nxprednew
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xprednewraw(i),xprednew(i));
        else
            fprintf(f,'%15g',xprednew(i));
        end
        fprintf(f,'%15g%15g%15g%15g%15g\n',newe(i),newci(i,1),newci(i,2),newpi(i,1),newpi(i,2));  
    end
end
fprintf(f,'\n');
%% Full model residuals
yhat = lmefull.Fitted;
rawres = lmefull.Residuals.Raw;
stares = lmefull.Residuals.Standardized;
stures = lmefull.Residuals.Studentized;
if save_resids == 1
    fres = fopen(erase(fn,'.txt')+"_full_model_residuals.txt", 'w');
    fprintf(fres,'%15s%15s%15s%15s%20s','x','y','yhat','Residual','Standard.Resid.');
    fprintf(fres,'%20s\n','Student.Resid.');
    for i = 1:n
        fprintf(fres,'%15.5e%15.5e%15.5e%15.5e%20.5e',x(i),y(i),yhat(i),rawres(i),stares(i));
        fprintf(fres,'%20.5e\n',stures(i));
    end
    fclose(fres);
end
%% Full model plots
fig{nmu+1} = figure('Name','Full Model','NumberTitle','off');
subplot(2,2,1)
plot(grpraw,grps.(3),'ko'); hold on;
plot(xpredraw,yplot,'k-','LineWidth',1.3);
plot(xpredraw,ciplot(:,1),'k--','LineWidth',1.0);
plot(xpredraw,ciplot(:,2),'k--','LineWidth',1.0);
xlabel('x'); ylabel('Mean(y)')
xl(1) = min(xpredraw); xl(2) = max(xpredraw);
yl(1) = min(ciplot(:,1)); yl(2) = max(ciplot(:,2)); 
xpt = xl(1) + 0.8*(xl(2)-xl(1));
ypt = yl(1) - 0.3*(yl(2)-yl(1));
text(xpt,ypt,'(bootstrapped are dotted)')
title(strcat(sprintf('%g',100*(1-Alpha)),'% confidence intervals'));
subplot(2,2,2)
plot(xraw,y,'ko'); hold on;
plot(xpredraw,yplot,'k-','LineWidth',1.3);
plot(xpredraw,piplot(:,1),'k--','LineWidth',1.0);
plot(xpredraw,piplot(:,2),'k--','LineWidth',1.0);
xlabel('x'); ylabel('y')
title(strcat(sprintf('%g',100*(1-Alpha)),'% prediction intervals'));
subplot(2,2,3)
plot(yhat,rawres,'ko'); hold on;
xl = xlim; plot([xl(1),xl(2)],[0,0],'k--');
xlabel('yhat'); ylabel('y - yhat')
title('Residuals')
subplot(2,2,4)
normplot(rawres); xlabel('y - yhat')
title('Normal plot')


%% Bootstraped tests and parameter estimates
if nboot > 0 
    %% Full model set up
    %More informative names
    ybar = yplot; effectbar = e;
    if nxprednew > 0
        newybar = newy; neweffectbar = newe;
    end
    bFfull = zeros(nboot); %Bootstrapped F test
    if save_boot_Fim == 1
        fbFfull= fopen(fbFfullfn, 'w');
        fprintf(fbFfull,'%13s\n','F');
    end
    bybar = zeros(nboot,ngrp); %Bootstrapped group means
    beffectbar = zeros(nboot,ngrp); %Bootstrapped effects
    validyfull = zeros(nboot,ngrp); %For validation residuals (response)
    valideffectfull = zeros(nboot,ngrp); %For validation residuals (effect)
    
    %% Generate residuals for bootstrapping
    res = zeros(n,1); grpmean = grps.(3); 
    i1 = zeros(1,ngrp); i2 = zeros(1,ngrp);
    i1(1) = 1; i2(1) = grpsize(1); 
    for j = 2:ngrp
        i1(j) = i2(j-1) + 1;
        i2(j) = grpsize(j) + i1(j) - 1;
    end
    for i = 1:n
        for j = 1:ngrp
            if x(i) == grp(j)
                res(i) = y(i) - grpmean(j);
            end
        end
    end
    
    %% Jacknife (needed for BCa)
    jx = zeros(n-1,n); jy = zeros(n-1,n); 
    jD = cell(nmu,n); jDeff = cell(nm,n);
    jsubject = zeros(n-1,n);
    for i = 1:n
        xj = x; xj(i) = []; jx(:,i) = xj;
        yj = y; yj(i) = []; jy(:,i) = yj;
        subjectj = subject; subjectj(i) = [];
        jsubject(:,i) = subjectj;
    end
    %Do the full model now; the polys are done below
    jybar = zeros(n,ngrp); jeffectbar = zeros(n,ngrp);
    for i = 1:n
        jDfull = Dfull; jDfull(i,:) = [];
        jxyfull = array2table([jy(:,i),jDfull],'VariableNames',vn);
        jlmefull = fitlm(jxyfull,fullmodel);
        jybar(i,:) = predict(jlmefull,xcalc);
        jeffectbar(i,:) = jybar(i,:) - jybar(i,1);
    end

    %% Initialise some arrays and generate the bootstrap samples
    bFbic0 = zeros(nboot,1); bFaic0 = zeros(nboot,1); bFpress0 = zeros(nboot,1);
    bFmse0 = zeros(nboot,1); bFFe0 = zeros(nboot,1); bFlof0 = zeros(nboot);            
    btbic0 = zeros(nboot,1); btaic0 = zeros(nboot,1); btpress0 = zeros(nboot,1);
    btmse0 = zeros(nboot,1); btFe0 = zeros(nboot,1); bFlof0 = zeros(nboot);
    yeffect_mse0 = zeros(nboot,1); yeffect_aic0 = zeros(nboot,1); 
    yeffect_bic0 = zeros(nboot,1); yeffect_press0 = zeros(nboot,1); 
    yeffect_Fe0 = zeros(nboot,1); modelb = cell([nboot,nmu]);
    sdb = zeros(nboot,nmu); sdb1b = zeros(nboot,nmu); bFim = zeros(nboot,nmu);
    betab = zeros(nboot,nmu,npmax); newobs = zeros(nboot,nxpred);
    bmuhat = zeros(nboot,nmu,nxpred); bmuhat0 = zeros(nboot,nmu);
    bmuhatnew = zeros(nboot,nmu,nxprednew); beffectnew = zeros(nboot,nmu,nxprednew);
    bmuci = zeros(nmu,nxpred); bypi = zeros(nmu,nxpred);
    beffect = zeros(nboot,nmu,nxpred); validy = zeros(nboot,nmu,nxpred);
    valideffect = zeros(nboot,nmu,nxpred);
    indexb = zeros(n,nboot);
    bmueci = zeros(nmu,nxpred); byepi = zeros(nmu,nxpred);
    fprintf('Starting %d bootstraps...\n', nboot)
    yb = zeros(n,nboot); yb0 = zeros(n,nboot);
    varNames = {'x','y','subject'};
    if strcmp(const_var,'no')
        for j = 1:ngrp
            resb = res(i1(j):i2(j)); iyb = subject(i1(j):i2(j));  %group residuals
            [~,bootsam] = bootstrp(nboot,@(resb)[],resb);
            resb = resb(bootsam); iyb = iyb(bootsam);
            indexb(i1(j):i2(j),:) = iyb(1:grpsize(j),1:nboot);
            yb0(i1(j):i2(j),:) = resb(1:grpsize(j),1:nboot);  %NH forced to be true; for significance tests
            yb(i1(j):i2(j),:) = resb(1:grpsize(j),1:nboot) + grpmean(j);
        end
    else
        [~,bootsam] = bootstrp(nboot,@(res)[],res);  %%%OR randres?
        resb = res(bootsam); iyb = subject(bootsam);
        for j = 1:ngrp
            indexb(i1(j):i2(j),:) = iyb(i1(j):i2(j),1:nboot);
            yb0(i1(j):i2(j),:) = resb(i1(j):i2(j),1:nboot);  %NH forced to be true; for significance tests
            yb(i1(j):i2(j),:) = resb(i1(j):i2(j),1:nboot) + grpmean(j);
        end
    end
    if strcmp(save_boot_resids,'yes')
        fbr = fopen(fbrn,'w');
        fprintf(fbr,'%15s','x');
        for i = 1:nboot
            fprintf(fbr,'%15s',"res"+string(i));
        end
        fprintf(fbr,'\n');
        for j = 1:n
            fprintf(fbr,'%15e',x(j));
            for i = 1:nboot
                fprintf(fbr,'%15e',yb0(j,i));
            end
            fprintf(fbr,'\n');    
        end
        fclose(fbr);
    end

    %% Now do the best-fit polynomial analysis on the bootstrap samples
    sumFfull = 0; %Sum for full-model F
    y0vec = y(i1(1):i2(1)); %Control-group y data
    for ib = 1:nboot
        %Full model first
        bxyfull = array2table([yb(:,ib),Dfull],'VariableNames',vn);
        blmefull = fitlm(bxyfull,fullmodel); dfu = ngrp - 1;
        bxyfull0 = array2table([yb0(:,ib),Dfull],'VariableNames',vn);
        blmefull0 = fitlm(bxyfull0,fullmodel); dfu = ngrp - 1;
        bFfull = (blmefull0.SST - blmefull0.SSE)/(dfu*blmefull0.MSE);
        if save_boot_Fim == 1
            fprintf(fbFfull,'%13.3f\n',bFfull);
        end
        if bFfull >= Ffull, sumFfull = sumFfull + 1; end
        bybar(ib,:) = predict(blmefull,xcalc);
        beffectbar(ib,:) = bybar(ib,:) - bybar(ib,1);
        [~,iC] = setdiff(subject(i1(1):i2(1)),iyb(:,ib)); nC = size(iC);
        if nC(1) > 0
            C = y0vec(iC);
            yj0 = datasample(C,1);
        else
            yj0 = datasample(y0vec,1);
        end
        for j = 1:ngrp
            yj = y(i1(j):i2(j));
            [~,iC] = setdiff(subject(i1(j):i2(j)),iyb(:,ib)); nC = size(iC);
            if nC(1) > 0
                C = yj(iC);
                yj = datasample(C,1);
            else
                yj = datasample(yj,1);
            end
            validyfull(ib,j) = yj;
            valideffectfull(ib,j) = yj - yj0;
        end
        
        %Now for the polynomials
        xyb = table(x,yb(:,ib),subject,'VariableNames',varNames);
        xyb0 = table(x,yb0(:,ib),subject,'VariableNames',varNames);
        [np,~,rss,mse,press,bic,aic,~,DF2,F,~,yeffectb,~,tVal,~] = ...
            fit_lme(nm,model,modeq,x,yb0(:,ib),subject,calc_press_boot,0,xeffect0,sxeffect);
        bim_mse = best_model(nm,np,mse,first_min);
        bFmse0(ib) = F(bim_mse); btmse0(ib) = tVal(bim_mse);
        yeffect_mse0(ib) = yeffectb(bim_mse);
        bim_aic = best_model(nm,np,aic,first_min); 
        bFaic0(ib) = F(bim_aic); btaic0(ib) = tVal(bim_aic);
        yeffect_aic0(ib) = yeffectb(bim_aic);
        bim_bic = best_model(nm,np,bic,first_min); 
        bFbic0(ib) = F(bim_bic); btbic0(ib) = tVal(bim_bic);
        yeffect_bic0(ib) = yeffectb(bim_bic);
        if calc_press == 1
            bim_press = best_model(nm,np,press,first_min);
            bFpress0(ib) = F(bim_press); btpress0(ib) = tVal(bim_press);
            yeffect_press0(ib) = yeffectb(bim_press);
        end
        if strcmp(Fdir,'forward')
            [bim_Fe,~,bFFe0(ib),~,~,~] = F_to_enter_fwrd(nm,np,DF2,F,rss,mse,Fcrit);
        else
            [bim_Fe,~,bFFe0(ib),~,~,~] = F_to_enter_back(nm,np,DF2,F,rss,mse,Fcrit);
        end
        btFe0(ib) = tVal(bim_Fe);
        yeffect_Fe0(ib) = yeffectb(bim_Fe);
        [bFlof0(ib),~,~,~] = LOF(x,yb0(:,ib),subject,model{1},Dfull,fullmodel,vn);
        for i = 1:nmu
            lme = fitlm(xyb0,model{imu(i)});
            npv = lme.NumCoefficients;
            if imu(i) > 1
                H = zeros(npv-1,npv);
                C = zeros(npv-1,1);
                for j = 1:npv-1
                    H(j,j+1) = 1;
                end
                %[~,bFim(ib,i),~] = coefTest(lme,H,C);
                lme00 = fitlm(xyb0,model{1});
                n00 = size(yb0(:,ib)); n00 = n00(1);
                SSE00 = var(yb0(:,ib))*(n00-1);
                bFim(ib,i) = (SSE00-lme.SSE)/(lme.MSE*(npv-1));
            else
                bFim(ib,i) = 0;
            end
            lme = fitlm(xyb,model{imu(i)});
            beta = lme.Coefficients.Estimate;
            sdb(ib,i) = sqrt(lme.MSE);
            modelb{ib,i} = lme; npv = size(beta);
            for j = 1:npv(1)
                betab(ib,i,j) = beta(j);
            end
            bmuhat0(ib,i) = predict(lme,table(xeffect0,'VariableNames',{'x'}));
            [~,iC] = setdiff(subject(i1(1):i2(1)),iyb(:,ib)); nC = size(iC);
            if nC(1) > 0
                C = y0vec(iC);
                yj0 = datasample(C,1);
            else
                yj0 = datasample(y0vec,1);
            end
            for j = 1:nxpred
                yj = y(i1(j):i2(j)); 
                [~,iC] = setdiff(subject(i1(j):i2(j)),iyb(:,ib)); nC = size(iC);
                if nC(1) > 0
                    C = yj(iC);
                    yj = datasample(C,1);
                else
                    yj = datasample(yj,1);
                end
                bmuhat(ib,i,j) = predict(lme,table(xpred(j),'VariableNames',{'x'}));
                validy(ib,i,j) = yj;
                beffect(ib,i,j) = bmuhat(ib,i,j) - bmuhat0(ib,i);
                valideffect(ib,i,j) = yj - yj0;
            end
            if nxprednew > 0
                for j = 1:nxprednew
                    bmuhatnew(ib,i,j) = predict(lme,table(xprednew(j),'VariableNames',{'x'}));
                    beffectnew(ib,i,j) = bmuhatnew(ib,i,j) - bmuhat0(ib,i);
                end
            end
        end
    end
    sumF_AIC = 0; sumF_MSE = 0; sumF_BIC = 0; 
    sumF_PRESS = 0; sumF_Fe = 0;
    sumtlo_AIC = 0; sumtlo_MSE = 0; sumtlo_BIC = 0; 
    sumtlo_PRESS = 0; sumtlo_Fe = 0;
    sumthi_AIC = 0; sumthi_MSE = 0; sumthi_BIC = 0; 
    sumthi_PRESS = 0; sumthi_Fe = 0;
    sumF_LOF = zeros(nmu); sumF_Fim = zeros(nmu);
    if save_boot_F == 1
        fb = fopen(fbn, 'w');
        fprintf(fb,'%13s%13s%13s%13s%13s\n', 'F_MSE','F_AIC','F_BIC', 'F_PRESS', 'F_Fenter');
    end
    if save_boot_t == 1
        tb = fopen(tbn, 'w');
        fprintf(tb,'%13s%13s%13s%13s%13s\n', 't_MSE','t_AIC','t_BIC', 't_PRESS', 't_Fenter');
    end
    if save_boot_effect == 1
        fprintf(eb,'%13s%13s%13s%13s%13s\n', 'E_MSE','E_AIC','E_BIC', 'E_PRESS', 'E_Fenter');
    end            
    if save_boot_Fim == 1
        fbFim = fopen(fbFimn, 'w'); 
        for i = 1:nmu
            fprintf(fbFim,'%13s',strcat('F_',string(imu(i))));
        end
        fprintf(fbFim,'\n');
    end
    if save_boot_LOF == 1
        lofb = fopen(lofbn, 'w'); 
        for i = 1:nmu
            fprintf(lofb,'%13s',strcat('LOF_',string(imu(i))));
        end
        fprintf(lofb,'\n');
    end

    for ib = 1:nboot
        if bFaic0(ib) >= Faic, sumF_AIC = sumF_AIC + 1; end
        if bFmse0(ib) >= Fmse, sumF_MSE = sumF_MSE + 1; end
        if bFbic0(ib) >= Fbic, sumF_BIC = sumF_BIC + 1; end
        if btaic0(ib) <= -abs(taic), sumtlo_AIC = sumtlo_AIC + 1; end
        if btmse0(ib) <= -abs(tmse), sumtlo_MSE = sumtlo_MSE + 1; end
        if btbic0(ib) <= -abs(tbic), sumtlo_BIC = sumtlo_BIC + 1; end
        if btaic0(ib) >= abs(taic), sumthi_AIC = sumthi_AIC + 1; end
        if btmse0(ib) >= abs(tmse), sumthi_MSE = sumthi_MSE + 1; end
        if btbic0(ib) >= abs(tbic), sumthi_BIC = sumthi_BIC + 1; end
        if calc_press_boot == 1
            if bFpress0(ib) >= Fpress, sumF_PRESS = sumF_PRESS + 1; end
            if btpress0(ib) <= -abs(tpress), sumtlo_PRESS = sumtlo_PRESS + 1; end
            if btpress0(ib) >= abs(tpress), sumthi_PRESS = sumthi_PRESS + 1; end
        end
        if bFFe0(ib) >= FFe, sumF_Fe = sumF_Fe + 1; end
        if btFe0(ib) <= -abs(tFe), sumtlo_Fe = sumtlo_Fe + 1; end
        if btFe0(ib) >= abs(tFe), sumthi_Fe = sumthi_Fe + 1; end
        if save_boot_F == 1
            fprintf(fb,'%13.3f%13.3f%13.3f', bFmse0(ib),bFaic0(ib),bFbic0(ib));
            if calc_press_boot == 1
                 fprintf(fb,'%13.3f',bFpress0(ib));
            end
            fprintf(fb,'%13.3f',bFFe0(ib));
            fprintf(fb,'\n');
        end
        if save_boot_t == 1
            fprintf(tb,'%13.3f%13.3f%13.3f', btmse0(ib),btaic0(ib),btbic0(ib));
            if calc_press_boot == 1
                 fprintf(tb,'%13.3f',btpress0(ib));
            end
            fprintf(tb,'%13.3f',btFe0(ib));
            fprintf(tb,'\n');
        end
        if save_boot_effect == 1
            fprintf(eb,'%13.3f%13.3f%13.3f', yeffect_mse0(ib),yeffect_aic0(ib),yeffect_bic0(ib));
            if calc_press_boot == 1
                 fprintf(eb,'%13.3f',yeffect_press0(ib));
            end
            fprintf(eb,'%13.3f',yeffect_Fe0(ib));
            fprintf(eb,'\n');
        end
        for i = 1:nmu
            if save_boot_Fim == 1
                fprintf(fbFim,'%13.3f',bFim(ib,i));
            end
            if bFim(ib,i) >= Fim(i)
                sumF_Fim(i) = sumF_Fim(i) + 1;
            end
            Fblofim = bFlof0(ib)*(ngrp-1)/(ngrp-n+DF(imu(i)));
            if save_boot_LOF == 1
                fprintf(lofb,'%13.3f',Fblofim);
            end
            if Fblofim >= Flof(i)
                sumF_LOF(i) = sumF_LOF(i) + 1;
            end
        end
        if save_boot_LOF == 1, fprintf(lofb,'\n'); end
        if save_boot_Fim == 1, fprintf(fbFim,'\n'); end
    end
    if save_boot_F == 1, fclose(fb); end
    if save_boot_t == 1, fclose(tb); end
    if save_boot_effect == 1, fclose(eb); end
    if save_boot_LOF == 1, fclose(lofb); end
    if save_boot_Fim == 1
        fclose(fbFim); fclose(fbFfull);
    end

    pFAIC = sumF_AIC/nboot; pFMSE = sumF_MSE/nboot; pFBIC = sumF_BIC/nboot;
    if calc_press_boot == 1 , pFPRESS = sumF_PRESS/nboot; end
    pFFe = sumF_Fe/nboot;
    ptAIClo = sumtlo_AIC/nboot; ptMSElo = sumtlo_MSE/nboot; ptBIClo = sumtlo_BIC/nboot;
    ptAIChi = sumthi_AIC/nboot; ptMSEhi = sumthi_MSE/nboot; ptBIChi = sumthi_BIC/nboot;
    ptAIC = ptAIClo + ptAIChi; ptMSE = ptMSElo + ptMSEhi; ptBIC = ptBIClo + ptBIChi; 
    if ptAIC > 1, ptAIC = 1; end
    if ptMSE > 1, ptMSE = 1; end
    if ptBIC > 1, ptBIC = 1; end
    ptIIImse = 0.5; ptIIIaic = 0.5; ptIIIbic = 0.5; ptIIIpress = 0.5; ptIIIFe = 0.5;
    if tmse < 0
        ptIIImse = ptMSElo;
    elseif tmse > 0
        ptIIImse = ptMSEhi;
    end
    if taic < 0
        ptIIIaic = ptAIClo;
    elseif taic > 0
        ptIIIaic = ptAIChi;
    end
    if tbic < 0
        ptIIIbic = ptBIClo;
    elseif tbic > 0
        ptIIIbic = ptBIChi;
    end
    if calc_press_boot == 1
        ptPRESSlo = sumtlo_PRESS/nboot; ptPRESShi = sumthi_PRESS/nboot;
        ptPRESS = ptPRESSlo + ptPRESShi;
        if ptPRESS > 1, ptPRESS = 1; end
        if tpress < 0
            ptIIIpress = ptPRESSlo;
        elseif tpress > 0
            ptIIIpress = ptPRESShi;
        end
    end
    ptFelo = sumtlo_Fe/nboot; ptFehi = sumthi_Fe/nboot;
    ptFe = ptFelo + ptFehi;
    if ptFe > 1, ptFe = 1; end
    if tFe < 0
        ptIIIFe = ptFelo;
    elseif tFe > 0
        ptIIIFe = ptFehi;
    end
    fprintf(f,'\n');
    fprintf(f,'***************** ANALYSIS BASED ON %d BOOTSTRAP SAMPLES ******************\n', nboot);
    rngdata = rng; fprintf(f,'\n');
    fprintf(f,'Random number generator: %s   RNG seed: %g\n', rngdata.Type, rngdata.Seed);
    fprintf(f,'\n');
    fprintf(f,'Best models: F and t tests (boostrapped p values).\n');
    fprintf(f,'p(F), p(t)I: probabilities of a Type I Error (false positive) under the NH y = b0.\n');
    fprintf(f,'p(t)III: probability of a Type III Error (true effect is opposite to that observed).\n');
    effect_text(f,xeffect0,sxeffect);
    fprintf(f,'Criterion %8s%10s%15s%15s%8s%10s%10s\n', 'F','p(F)','Effect','SE','t','p(t)I','p(t)III');
    fprintf(f,'     MSE: %8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Fmse, pFMSE, yeffect(im_mse), sef(im_mse), tmse, ptMSE, ptIIImse);
    fprintf(f,'     AIC: %8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Faic, pFAIC, yeffect(im_aic), sef(im_aic), taic, ptAIC, ptIIIaic);
    fprintf(f,'     BIC: %8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Fbic, pFBIC, yeffect(im_bic), sef(im_bic), tbic, ptBIC, ptIIIbic);
    if calc_press_boot == 1
        fprintf(f,'   PRESS: %8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Fpress, pFPRESS, yeffect(im_press), sef(im_press), tpress, ptPRESS, ptIIIpress);
    end
    fprintf(f,'   F>%3.1f: %8.2f%10.5f%15.5e%15.5e%8.2f%10.5f%10.5f\n', Fcrit, FFe, pFFe, yeffect(im_Fe), sef(im_Fe), tFe, ptFe, ptIIIFe);
    fprintf(f,'\n');

    for i = 1:nmu
        %% For each best-fit model:
        im = imu(i); fprintf(f,'\n');
        fprintf(f,'MODEL %d: %s\n', im, modeq{im});
        fprintf(f,'\n');
        if Fim(i) == 0
            fprintf(f,'Constant model: no F test\n');
        else
            fprintf(f,'F test: F = %7.3f, p(F) = %7.5f\n', Fim(i),sumF_Fim(i)/nboot);
        end
        fprintf(f,'\n');
        if isnan(Flof(i)) || Flof(i) == Inf, sumF_LOF(i) = NaN; end
        if Flof(i) == 0
            fprintf(f,'Full model: no lack of fit test\n');
        else
            fprintf(f,'Lack of fit test: F = %7.3f, p(F) = %7.5f\n', Flof(i),sumF_LOF(i)/nboot);
        end
        fprintf(f,'\n');

        %% Parameter estimates
        fprintf(f,'Parameter estimates and %s%% confidence limits for model %d:\n', CL,im);                                
        jbeta = zeros(n,npara(imu(i)));
        jSD = zeros(n,1); jSDb1 = zeros(n,1);
        jmuhat = zeros(n,nxpred); jeffect = zeros(n,nxpred);
        jmuhatnew = zeros(n,nxprednew); jeffectnew = zeros(n,nxprednew);
        for j = 1:n
            jxytbl = table(jx(:,j),jy(:,j),jsubject(:,j),'VariableNames',varNames);
            lme = fitlm(jxytbl,model{imu(i)});
            jbeta(j,:) = lme.Coefficients.Estimate;
            jSD(j) = sqrt(lme.MSE);
            bmuhat0j = predict(lme,table(xeffect0,'VariableNames',{'x'}));
            for ij = 1:nxpred
                jmuhat(j,ij) = predict(lme,table(xpred(ij),'VariableNames',{'x'}));
                jeffect(j,ij) = jmuhat(j,ij) - bmuhat0j;
            end
            if nxprednew > 0
                for ij = 1:nxprednew
                    jmuhatnew(j,ij) = predict(lme,table(xprednew(ij),'VariableNames',{'x'}));
                    jeffectnew(j,ij) = jmuhatnew(j,ij) - bmuhat0j;
                end
            end
        end
        fprintf(f,'%9s%15s%15s%15s%15s\n','Parameter','Estimate','SE','Lower','Upper');
        if save_boot_paras == 1
            pbfn = erase(fn,".txt")+heirarch+"polynomial-"+smxd+"_boot-paras_model-"+string(im)+".txt";
            pb = fopen(pbfn,'w');
            for j = 1:npara(imu(i))
                if j == 1
                    fprintf(pb,'%15s','b0');
                elseif ~contains(betan(i,j),'^')
                    fprintf(pb,'%15s','b1');
                else
                    bp = strsplit(string(betan(i,j)),'^');
                    fprintf(pb,'%15s','b'+bp(2));
                end
            end
            fprintf(pb,'%15s','sqrt(MSE)');
            fprintf(pb,'\n');
            for k = 1:nboot
                for j = 1:npara(imu(i))
                    fprintf(pb,'%15e',betab(k,i,j));
                end
                fprintf(pb,'%15e',sdb(k,i));
                fprintf(pb,'\n');
            end
            fclose(pb);
        end
        for j = 1:npara(imu(i))
            [~,CI] = BCa_bootstrap(betaim(i,j),jbeta(:,j),betab(:,i,j),Alpha);
            SEbetaim = std(betab(:,i,j));
            if j == 1
                fprintf(f,'%9s','b0');
            elseif ~contains(betan(i,j),'^')
                fprintf(f,'%9s','b1');
            else
                bp = strsplit(string(betan(i,j)),'^');
                fprintf(f,'%9s','b'+bp(2));
            end
            fprintf(f,'%15g',betaim(i,j));
            fprintf(f,'%15g',SEbetaim);
            fprintf(f,'%15g',CI(1));
            fprintf(f,'%15g',CI(2));
            fprintf(f,'\n');
        end
        fprintf(f,'\n');

        %% Variance-covariance matrix of parameters
        A = zeros(nboot,npara(imu(i)));
        for ii = 1:nboot
            for jj = 1:npara(imu(i))
                A(ii,jj) = betab(ii,i,jj); 
            end
        end
        C = cov(A); ncv = size(C);
        fprintf(f,'Variance-covariance matrix of parameters:\n');
        for ii = 1:ncv(1)
            for jj = 1:ncv(2)
                fprintf(f,'%15g',C(ii,jj));
            end
            fprintf(f,'\n');
        end
        fprintf(f,'\n');

        [~,CI] = BCa_bootstrap(SD(i),jSD,sdb(:,i),Alpha);
        fprintf(f,'Error SD = sqrt(MSE): %g (%g, %g)\n', SD(i),CI(1),CI(2));
        fprintf(f,'\n');

        %% Predicted responses with confidence intervals (CI) and prediction intervals (PI)
        fprintf(f,'Predicted response with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
        if strcmp(center,'yes')
            fprintf(f,'%15s%15s','x','x-xbar');
        else
            fprintf(f,'%15s','x');
        end
        fprintf(f,'%15s%15s%15s%15s%15s\n','yhat','LowerCL','UpperCL','LowerPL','UpperPL');
        PIb = zeros(nxpred,2); CIb = zeros(nxpred,2);
        for ij = 1:nxpred
            [~,CI] = BCa_bootstrap(muhat(ij,i),jmuhat(:,ij),bmuhat(:,i,ij),Alpha);
            validres = validy(:,i,ij) - bmuhat(:,i,ij);
            mo = mean(bmuhat(:,i,ij)) - bmuhat(:,i,ij) + validres;
            PI = prctile(mo,[100*0.5*Alpha,100*(1-0.5*Alpha)]);
            PI = PI + muhat(ij,i); newobs(:,ij) = mo + muhat(ij,i);
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xpredraw(ij),xpred(ij));
            else
                fprintf(f,'%15g',xpred(ij));
            end
            CIb(ij,1) = CI(1); CIb(ij,2) = CI(2);
            PIb(ij,1) = PI(1); PIb(ij,2) = PI(2);
            fprintf(f,'%15g%15g%15g%15g%15g\n',muhat(ij,i),CI(1),CI(2),PI(1),PI(2));
        end
        if save_boot_paras == 1
            save_data(datafn,im,nxpred,nboot,bmuhat(:,i,:),'mean_response');
            save_data(datafn,im,nxpred,nboot,newobs,'new_observation');
        end
        
        figure(fig{i})
        subplot(2,2,1); hold on;
        plot(grpraw,CIb(:,1),'k:','LineWidth',1.2);
        plot(grpraw,CIb(:,2),'k:','LineWidth',1.2);
        subplot(2,2,2); hold on;
        plot(grpraw,PIb(:,1),'k:','LineWidth',1.2);
        plot(grpraw,PIb(:,2),'k:','LineWidth',1.2);
        saveas(figure(fig{i}),strcat(plotfn,num2str(im),'.png'));
        if nxprednew > 0  %Predict new responses
            for ij = 1:nxprednew
                if strcmp(center,'yes')
                    fprintf(f,'%15g%15g',xprednewraw(ij),xprednew(ij));
                else
                    fprintf(f,'%15g',xprednew(ij));
                end
                [~,CI] = BCa_bootstrap(muhatnew(ij,i),jmuhatnew(:,ij),bmuhatnew(:,i,ij),Alpha);
                for kkk = 1:nxpred-1
                    if xpred(kkk) <= xprednew(ij) && xpred(kkk+1) >= xprednew(ij)
                        dx = (xpred(kkk+1)-xpred(kkk));
                        dx0 = xprednew(ij)-xpred(kkk);
                        slope = (PIb(kkk+1,1)-PIb(kkk,1))/dx;
                        PI(1) = PIb(kkk,1) + slope*dx0;
                        slope = (PIb(kkk+1,2)-PIb(kkk,2))/dx;
                        PI(2) = PIb(kkk,2) + slope*dx0;
                    end
                end
                fprintf(f,'%15g%15g%15g%15g%15g\n',muhatnew(ij,i),CI(1),CI(2),PI(1),PI(2));
            end    
        end
        fprintf(f,'\n');
        
        %% Predicted effects with confidence intervals (CI) and prediction intervals (PI)
        fprintf(f,'Effect size with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
        if strcmp(center,'yes')
            fprintf(f,'%15s%15s','x','x-xbar');
        else
            fprintf(f,'%15s','x');
        end
        fprintf(f,'%15s%15s%15s%15s%15s\n','Effect','LowerCL','UpperCL','LowerPL','UpperPL');
        for ij = 1:nxpred
            if ij == 1
                CI = [0,0];
            else
                [~,CI] = BCa_bootstrap(effect(ij,i),jeffect(:,ij),beffect(:,i,ij),Alpha);
            end
            valideffectres = valideffect(:,i,ij) - beffect(:,i,ij);
            mo = mean(beffect(:,i,ij)) - beffect(:,i,ij) + valideffectres;
            PI = prctile(mo,[100*0.5*Alpha,100*(1-0.5*Alpha)]);
            PI = PI + effect(ij,i); newobs(:,ij) = mo + effect(ij,i);
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xpredraw(ij),xpred(ij));
            else
                fprintf(f,'%15g',xpred(ij));
            end
            CIb(ij,1) = CI(1); CIb(ij,2) = CI(2);
            PIb(ij,1) = PI(1); PIb(ij,2) = PI(2);
            fprintf(f,'%15g%15g%15g%15g%15g\n',effect(ij,i),CI(1),CI(2),PI(1),PI(2));
        end
        if save_boot_paras == 1
            save_data(datafn,im,nxpred,nboot,beffect(:,i,:),'mean_effect');
            save_data(datafn,im,nxpred,nboot,newobs,'new_effect');
        end
        if nxprednew > 0  %Predict new effects
            for ij = 1:nxprednew
                [~,CI] = BCa_bootstrap(effectnew(ij,i),jeffectnew(:,ij),beffectnew(:,i,ij),Alpha);
                if strcmp(center,'yes')
                    fprintf(f,'%15g%15g',xprednewraw(ij),xprednew(ij));
                else
                    fprintf(f,'%15g',xprednew(ij));
                end
                for kkk = 1:nxpred-1  %Use linear interpolation for the PIs
                    if xpred(kkk) <= xprednew(ij) && xpred(kkk+1) >= xprednew(ij)
                        dx = (xpred(kkk+1)-xpred(kkk));
                        dx0 = xprednew(ij)-xpred(kkk);
                        slope = (PIb(kkk+1,1)-PIb(kkk,1))/dx;
                        PI(1) = PIb(kkk,1) + slope*dx0;
                        slope = (PIb(kkk+1,2)-PIb(kkk,2))/dx;
                        PI(2) = PIb(kkk,2) + slope*dx0;
                    end
                end
                fprintf(f,'%15g%15g%15g%15g%15g\n',effectnew(ij,i),CI(1),CI(2),PI(1),PI(2));  
            end
        end
        fprintf(f,'\n');
    end
    fprintf(f,'\n');
    
    %% Full model (gropup means)
    dfu = ngrp - 1; dfl = n - lmefull.NumCoefficients;
    fprintf(f,'FULL MODEL: Group means (probably best for predictions)\n'); fprintf(f,'\n');
    fprintf(f,'F test: F(%d,%d) = %7.3f, p(F) = %7.5f\n', dfu,dfl,Ffull,sumFfull/nboot);
    fprintf(f,'\n');
    %% Full model predicted responses with confidence intervals (CI) and prediction intervals (PI)
    fprintf(f,'Predicted response with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
    if strcmp(center,'yes')
        fprintf(f,'%15s%15s','x','x-xbar');
    else
        fprintf(f,'%15s','x');
    end
    fprintf(f,'%15s%15s%15s%15s%15s\n','yhat','LowerCL','UpperCL','LowerPL','UpperPL');
    PIb = zeros(nxpred,2); CIb = zeros(nxpred,2);
    for ij = 1:nxpred
        [~,CI] = BCa_bootstrap(ybar(ij),jybar(:,ij),bybar(:,ij),Alpha);
        validres = validyfull(:,ij) - bybar(:,ij);
        mo = mean(bybar(:,ij)) - bybar(:,ij) + validres;
        PI = prctile(mo,[100*0.5*Alpha,100*(1-0.5*Alpha)]);
        PI = PI + ybar(ij); newobs(:,ij) = mo + ybar(ij);
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xpredraw(ij),xpred(ij));
        else
            fprintf(f,'%15g',xpred(ij));
        end
        CIb(ij,1) = CI(1); CIb(ij,2) = CI(2);
        PIb(ij,1) = PI(1); PIb(ij,2) = PI(2);
        fprintf(f,'%15g%15g%15g%15g%15g\n',ybar(ij),CI(1),CI(2),PI(1),PI(2));
    end
    if save_boot_paras == 1
        save_data(datafullfn,0,nxpred,nboot,bmuhat(:,i,:),'mean_response');
        save_data(datafullfn,0,nxpred,nboot,newobs,'new_observation');
    end
    figure(fig{nmu+1})
    subplot(2,2,1); hold on;
    plot(grpraw,CIb(:,1),'k:','LineWidth',1.2);
    plot(grpraw,CIb(:,2),'k:','LineWidth',1.2);
    subplot(2,2,2); hold on;
    plot(grpraw,PIb(:,1),'k:','LineWidth',1.2);
    plot(grpraw,PIb(:,2),'k:','LineWidth',1.2);
    saveas(figure(fig{nmu+1}),strcat(plotfullfn+'.png'));
    if nxprednew > 0  %Predict new responses
        [newy,newci,newpi] = FullModel_pred(xpred,ybar,CIb,PIb,xprednew);
        for ij = 1:nxprednew
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xprednewraw(ij),xprednew(ij));
            else
                fprintf(f,'%15g',xprednew(ij));
            end
            fprintf(f,'%15g%15g%15g%15g%15g\n',newy(ij),newci(ij,1),newci(ij,2),newpi(ij,1),newpi(ij,2));  
        end    
    end
    fprintf(f,'\n');
    %% Full model predicted effects with confidence intervals (CI) and prediction intervals (PI)
    fprintf(f,'Effect size with %s%% confidence limits (CL) and prediction limits (PL):\n',CL);
    if strcmp(center,'yes')
        fprintf(f,'%15s%15s','x','x-xbar');
    else
        fprintf(f,'%15s','x');
    end
    fprintf(f,'%15s%15s%15s%15s%15s\n','Effect','LowerCL','UpperCL','LowerPL','UpperPL');
    for ij = 1:nxpred
        if ij == 1
            CI = [0,0];
        else
            [~,CI] = BCa_bootstrap(effectbar(ij),jeffectbar(:,ij),beffectbar(:,ij),Alpha);
        end
        valideffectres = valideffectfull(:,ij) - beffect(:,ij);
        mo = mean(beffectbar(:,ij)) - beffectbar(:,ij) + valideffectres;
        PI = prctile(mo,[100*0.5*Alpha,100*(1-0.5*Alpha)]);
        PI = PI + effectbar(ij); newobs(:,ij) = mo + effectbar(ij);
        if strcmp(center,'yes')
            fprintf(f,'%15g%15g',xpredraw(ij),xpred(ij));
        else
            fprintf(f,'%15g',xpred(ij));
        end
        CIb(ij,1) = CI(1); CIb(ij,2) = CI(2);
        PIb(ij,1) = PI(1); PIb(ij,2) = PI(2);
        fprintf(f,'%15g%15g%15g%15g%15g\n',effectbar(ij),CI(1),CI(2),PI(1),PI(2));
    end
    if save_boot_paras == 1
        save_data(datafullfn,0,nxpred,nboot,beffect(:,i,:),'mean_effect');
        save_data(datafullfn,0,nxpred,nboot,newobs,'new_effect');
    end
    if nxprednew > 0  %Predict new effects
        [newe,newci,newpi] = FullModel_pred(xpred,effectbar,CIb,PIb,xprednew);
        for ij = 1:nxprednew
            if strcmp(center,'yes')
                fprintf(f,'%15g%15g',xprednewraw(ij),xprednew(ij));
            else
                fprintf(f,'%15g',xprednew(ij));
            end
            fprintf(f,'%15g%15g%15g%15g%15g\n',newe(ij),newci(ij,1),newci(ij,2),newpi(ij,1),newpi(ij,2));  
        end
    end
    fprintf(f,'\n');
end

%% Finish up
fcn = strcat(dir,filename,'_BestFitPoly_Config.txt');
copyfile('BestFitPoly_Config.txt', fcn);
fclose('all');
toc
diary off;
if prt_lme == 1
    fn = strcat(dir,filename,'_printout.txt');
    f = fopen(fn, 'r'); tline = [""]; i = 0;
    while feof(f) ~= 1
        i = i + 1; tline(i) = fgets(f);
        tline(i) = erase(tline(i),'<strong>');
        tline(i) = erase(tline(i),'</strong>');
    end
    fclose(f); nl = size(tline);
    f = fopen(fn, 'w'); 
    for i = 1:nl(2)
        fprintf(f,'%s',tline(i));
    end
    fclose(f);
end


function save_data(datafn,im,nxpred,nboot,data,text)
    if im > 0
        fn = strcat(datafn,text,'_model-',num2str(im),'.txt');
    else
        fn = strcat(datafn,text,'.txt');
    end
    f = fopen(fn,'w');
    for j = 1:nxpred
        xs = strcat('x',num2str(j)); fprintf(f,'%15s',xs);
    end
    fprintf(f,'\n');
    for k = 1:nboot
        for j = 1:nxpred
            fprintf(f,'%15.5e',data(k,j));
        end
        fprintf(f,'\n');    
    end
    fclose(f);
end

function [yhat,ci,pi,effect,eci,epi] = polypred(model,modeleq,x,x0,Alpha)
    nx = size(x); yhat = zeros(nx(1),1); effect = zeros(nx(1),1);
    ci = zeros(nx(1),2); pi = zeros(nx(1),2);
    eci = zeros(nx(1),2); epi = zeros(nx(1),2);
    Cov = model.CoefficientCovariance;
    Cov(1,:) = []; Cov(:,1) = []; mse = model.MSE;
    np = model.NumCoefficients; xh = zeros(np-1,1); 
    n = model.NumObservations; t = tinv(1-0.5*Alpha,n-np);
    sub = strfind(modeleq{1},'subject');  nsub = size(sub);
    terms = split(modeleq,'+'); nterms = size(terms);
    nterms = nterms(1) - 2*nsub(2);
    yhat0 = predict(model,table(x0,'VariableNames',{'x'}));
    for i = 1:nx(1)
        [~,ci(i,:)] = predict(model,table(x(i),'VariableNames',{'x'}),'Alpha',Alpha);
        [yhat(i),pi(i,:)] = predict(model,table(x(i),'VariableNames',{'x'}),'Prediction','observation','Alpha',Alpha);
        effect(i) = yhat(i) - yhat0;
        for k = 2:nterms
             s = terms(k);
             powx = strfind(s{1},'x');
             powx = size(powx); powx = powx(2);
             xh(k-1,1) = x(i)^powx - x0^powx;
        end
        s2 = xh'*Cov*xh; se = sqrt(s2); sd = sqrt(2*mse+s2);
        eci(i,1) = effect(i)-t*se; eci(i,2) = effect(i)+t*se;
        epi(i,1) = effect(i)-t*sd; epi(i,2) = effect(i)+t*sd;
    end
end

function [newy,newci,newpi] = FullModel_pred(x,y,ci,pi,xnew)
    m = size(x); m = m(1)-1; n = size(xnew); n = n(1);
    newy = zeros(n); newci = zeros(n,2); newpi = zeros(n,2);
    for i = 1:n
        for j = 1:m
            if xnew(i) >= x(j) && xnew(i) <= x(j+1)
                f = (xnew(i) - x(j))/(x(j+1) - x(j));
                newy(i) = y(j) + f*(y(j+1) - y(j));
                newci(i,1) = ci(j,1) + f*(ci(j+1,1) - ci(j,1));
                newci(i,2) = ci(j,2) + f*(ci(j+1,2) - ci(j,2));
                newpi(i,1) = pi(j,1) + f*(pi(j+1,1) - pi(j,1));
                newpi(i,2) = pi(j,2) + f*(pi(j+1,2) - pi(j,2));
                break
            end
        end
    end
end

function [np,df,rss,mse,press,bic,aic,DF1,DF2,F,pValF,yeffect,sef,tVal,pValt] = ...
    fit_lme(nm,model,modeq,x,y,subject,calc_press,iprint,xeffect1,sxeffect)
    n = size(x); F = ones(1,nm); n = n(1); 
    df = zeros(1,nm); rss = zeros(1,nm); press = zeros(1,nm); 
    np = zeros(1,nm); mse = zeros(1,nm); bic = zeros(1,nm); 
    aic = zeros(1,nm); yeffect = zeros(1,nm); sef = zeros(1,nm);
    tVal = zeros(1,nm); pValt = zeros(1,nm); 
    pValF =  zeros(1,nm); DF1 =  zeros(1,nm); DF2 = zeros(1,nm);
    for i = 1:nm
        xy = xytable(x,y,subject);
        lmej = fitlm(xy,model{i});
        if iprint == 1
            fprintf('\n');
            fprintf('%d: %s\n',i, modeq{i});
            LinearModel = lmej
        end
        lme = lmej; xeffect0 = xeffect1;
        if i > 1
            Cov = lme.CoefficientCovariance;
            Cov(1,:) = []; Cov(:,1) = []; deg = 1;
            yeffect0 = predict(lme,table(xeffect0,'VariableNames',{'x'}));
            np(i) = lme.NumCoefficients; xh = zeros(np(i)-1,1); 
            beta = lme.Coefficients.Estimate;
            beta_SE = lme.Coefficients.SE; beta_tStat_max = 0;
            beta_tStat = lme.Coefficients.tStat; jmax = 1;
            betanames = lme.CoefficientNames';
            if contains(betanames{np(i)},'^')
                s = split(betanames{np(i)},'^');
                deg = str2double(s{2});
            end
            polybs = zeros(deg+1,1);
            polybs(1) = beta(1);
            for j = 2:np(i)
                if abs(beta_tStat(j)) > beta_tStat_max
                    beta_tStat_max = beta_tStat(j); jmax = j;
                end
                if contains(betanames{j},'^')
                    s = split(betanames{j},'^');
                    polybs(str2double(s{2}) + 1) = beta(j);
                end
                if ~contains(betanames{j},'^') && contains(betanames{j},'x')
                   polybs(2) = beta(j);
                end
            end
            polybs = flip(polybs);
            yeffect1 = polyval(polybs,x(n)) - yeffect0;
            maxeffect = abs(yeffect1);
            yeffect(i) = yeffect1;
            xeffectval = x(n);
            if deg > 1
               polyd = polyder(polybs);
               r = roots(polyd); nr = size(r);
               if nr(1) > 0
                   for j = 1:nr(1)
                       if isreal(r(j)) && (r(j) > x(1) && r(j) < x(n))
                           yeffect1 = polyval(polybs,r(j)) - yeffect0;
                           if abs(yeffect1) > maxeffect
                               maxeffect = abs(yeffect1);
                               yeffect(i) = yeffect1;
                               xeffectval = r(j);
                           end
                       end
                   end
               end
            end
            sub = strfind(model{i},'subject'); nsub = size(sub);
            terms = split(model{i},'+'); nterms = size(terms);
            nterms = nterms(1) - 2*nsub(2);
            for k = 2:nterms
                 s = terms(k);
                 powx = strfind(s{1},'x');
                 powx = size(powx); powx = powx(2);
                 xh(k-1,1) = xeffectval^powx - xeffect0^powx;
            end
            sef(i) = sqrt(xh'*Cov*xh);
            if strcmp(sxeffect,'maxeffect')
                tVal(i) = yeffect(i)/sef(i);
            else
                tVal(i) = beta_tStat(j);
            end
            pValt(i) = 2*tcdf(abs(tVal(i)),n-np(i),'upper');
        else
            np(i) = 1;  tVal(i) = 0; pValt(i) = 1;
            yeffect(i) = 0; sef(i) = 0; 
        end
        if calc_press == 1
            hat = lme.Diagnostics.HatMatrix;
            res = lme.Residuals.Raw;
            for j = 1:n
                dy = res(j)/(1 - hat(j,j));
                press(i) = press(i) + dy*dy;
            end
        end
        mse(i) = lme.MSE; rss(i) = lme.SSE; df(i) = lme.DFE; 
        bic(i) = lme.ModelCriterion.BIC;
        aic(i) = lme.ModelCriterion.AIC;
        if i > 1
            H = zeros(np(i)-1,np(i));
            C = zeros(np(i)-1,1);
            for j = 1:np(i)-1
                H(j,j+1) = 1;
            end
            [pValF(i),F(i),DF1(i)] = coefTest(lme,H,C); DF2(i) = lme.DFE;                
        else
            pValF(i) = 1; DF2(i) = n-1; DF1(i) = n-1;
        end
    end
end

function im = best_model(nm,np,c,first_min)  %c is the best-fit criterion
    np0 = unique(np); np0 = sort(np0); c0 = c(1);
    m = size(np0); m = m(2); i0 = zeros(1,m); 
    j = 1; i0(1) = 1; %for each number of parameters, select the model with the lowest criterion value
    for i = 2:nm
        if np(i) > np0(j)
            j = j + 1;
            c0 = c(i);
            i0(j) = i;
        end
        if c(i) < c0
            c0 = c(i); 
            i0(j) = i;
        end
    end
    im = 1; min_c = c(1); do_c = 1;
    for i = 2:m
        if strcmp(first_min,'yes')
            if c(i0(i)) >= min_c && im > 1, do_c = 0; end
        end
        if c(i0(i)) < min_c && do_c == 1
            min_c = c(i0(i)); im = i0(i);
        end
    end
end

function [im_F,np_Fe,FF,i0,Fm,nF] = F_to_enter_fwrd(nm,np,df,F,rss,mse,Fcrit)
    np0 = unique(np); np0 = sort(np0); rss0 = rss(1);
    nF = size(np0); nF = nF(2); i0 = zeros(1,nF);
    np_Fe = zeros(1,nF); np_Fe(1) = np(1);
    j = 1; i0(1) = 1; %for each number of parameters, select the model with the lowest rss
    for i = 2:nm
        if np(i) > np0(j)
            j = j + 1;
            rss0 = rss(i);
            i0(j) = i;
            np_Fe(j) = np(i);
        end
        if rss(i) < rss0
            rss0 = rss(i); 
            i0(j) = i;
            np_Fe(j) = np(i);
        end
    end
    do_test = 1; Fm = zeros(1,nF-1); 
    im_F = 1; Fm(1) = 1; FF = 1;
    for i = 2:nF
        dfu = df(im_F)-df(i0(i));
        Fm(i) = (rss(im_F) - rss(i0(i)))/(dfu*mse(i0(i)));
        if Fm(i) <= Fcrit && im_F > 1
            do_test = 0;
        end
        if Fm(i) > Fcrit && do_test == 1
            im_F = i0(i);
        end
    end
    if im_F > 1
        FF = F(im_F);
    end
end

function [im_F,np_Fe,FF,i0,Fm,nF] = F_to_enter_back(nm,np,df,F,rss,mse,Fcrit)
    np0 = unique(np); np0 = sort(np0); rss0 = rss(1);
    nF = size(np0); nF = nF(2); i0 = zeros(1,nF);
    np_Fe = zeros(1,nF); np_Fe(1) = np(1);
    j = 1; i0(1) = 1; %for each number of parameters, select the model with the lowest rss
    for i = 2:nm
        if np(i) > np0(j)
            j = j + 1;
            rss0 = rss(i);
            i0(j) = i;
            np_Fe(j) = np(i);
        end
        if rss(i) < rss0
            rss0 = rss(i); 
            i0(j) = i;
            np_Fe(j) = np(i);
        end
    end
    do_test = 1; Fm = zeros(1,nF-1); 
    im_F = 1; Fm(1) = 1; FF = 1;
    for i = nF:-1:2
        dfu = df(i0(i-1))-df(i0(i));
        Fm(i) = (rss(i0(i-1))-rss(i0(i)))/(dfu*mse(i0(i)));
        if Fm(i) > Fcrit && do_test == 1
            im_F = i0(i);
            do_test = 0;
        end
    end
    if im_F > 1
        FF = F(im_F);
    end
end

function [Flof, dfu, dffull, pFlof] = LOF(x,y,subject,model,Dfull,fullmodel,vn)
    xy = xytable(x,y,subject);
    xyfull = array2table([y,Dfull],'VariableNames',vn);
    lme = fitlm(xy,model);
    lmefull = fitlm(xyfull,fullmodel);
    if lme.NumCoefficients == lmefull.NumCoefficients
        Flof = 0; dfu = -1; dffull = -1; pFlof = -1;
    else
        dfim = lme.DFE; rssim = lme.SSE;
        msefull = lmefull.MSE; dffull = lmefull.DFE;
        dfu = dfim - dffull; rssfull = lmefull.SSE;
        Flof = (rssim - rssfull)/(dfu*msefull);
        pFlof = fcdf(Flof,dfu,dffull,'upper');
    end
end

function effect_text(f,xeffect0,sxeffect)
    if strcmp(sxeffect,'maxeffect')
        fprintf(f,'Effect = yhat(x)-yhat(%g) +/- SE, where x maximises |Effect|. t = Effect/SE.\n',xeffect0);
    else
        fprintf(f,'t = maximum t value for the model parameters (without regard to sign).\n');
    end
end

function fmtout = this_one(f,im,i0,u,cr)
    fmtout = '%15.5e';
    if im == i0 && u == 1
        fprintf(f,'*');
        fmtout = '%14.5e';
    end
    if cr == 1, fprintf(f,'\n'); end
end

function xyt = xytable(x,y,subject)
    xyt = table(x,y,subject);
end

function [p,CI] = BCa_bootstrap(data,loo,boot,Alpha,varargin)

    % Computes the bias-corrected and accelerated bootstrap estimate of  Efron,
    % B., & Tibshirani, R. J. (1993). An Introduction to the Bootstrap, Chapman
    % & Hall/CRC: New York.
    % 
    % Usage:
    % [p,CI] = BCa_bootstrap(data,loo,boot,null,confidence)
    % [p,CI] = BCa_bootstrap(data,loo,boot,null,confidence,adjustment)
    % 
    % p is the two-tailed p-value and CI is the confidence interval.
    % 
    % data - the statistic of interest calculated on the data
    % loo - a vector of length N of the leave-one-out values of the statistic
    %       of interest.
    % boot - the bootstrapped values of the statistic of interest
    % null - (optional) the value of the statistic of interest under the null
    %        hypothesis. Defaults to 0.
    % confidence - (optional) the % confidence for upper and lower bounds of
    %              the confidence interval. Defaults to 95%
    % adjustment - (optional) NOT RECOMMENDED. This is included for a
    %              specialized application. The integer value entered here will
    %              include that many observations equal to the null value into
    %              the bootstrap values AFTER calculating the bias and
    %              acceleration.
    % 
    % Jared Van Snellenberg, PhD 2009

    if any(isnan(boot))
        error('Error, NaNs in the bootstrapped data');
    end
    
    nuj = size(unique(loo));
    nub = size(unique(boot));
    if nub(1) <= 1
        CI = [data data]; p = 0.5; return
    end

    if isempty(varargin)||isempty(varargin{1})
        null = 0;
    else
        null = varargin{1};
    end
    if isempty(varargin)||length(varargin)<2||isempty(varargin{2})
        c = 0.5*Alpha;
    else
        c = (1-varargin{2})/2;
    end
    if isempty(varargin)||length(varargin)<3||isempty(varargin{3})
        adjust = 0;
    else
        adjust = varargin{3};
    end

    boot = sort(boot);
    
    ssq = sum( (mean(loo) - loo).^2 );

    z = norminv(sum(boot < data) / length(boot));
    if z == -Inf
        alpha(1) = 0; alpha(2) = 0;
    elseif z == Inf
        alpha(1) = 1; alpha(2) = 1; 
    elseif ssq == 0 || nuj(1) <= 1
        alpha(1) = c; alpha(2) = 1 - c; a = 0;  %use percentile method in this case
    else
        a = sum( (mean(loo) - loo).^3 ) / (6 * ssq ^(3/2));
        alpha(1) = normcdf( z + (z + norminv(c)) / (1 - a*(z + norminv(c))) );
        alpha(2) = normcdf( z + (z + norminv(1-c)) / (1 - a*(z + norminv(1-c))) );
    end

    if adjust
        boot(end+1:end+adjust) = null;
        boot = sort(boot);
    end

%     loo
%     boot
%     fix(alpha(1)*length(boot))
%     fix(alpha(2)*length(boot))
    CI = [boot( max([fix(alpha(1)*length(boot)) 1]) ) boot(fix(alpha(2)*length(boot)))];

    p = sum(boot < null) / length(boot);
    if ~p
        p = 1 / length(boot);
    elseif p == 1
        p = 1 - 1 / length(boot);
    end
    if ssq > 0 && (z ~= -Inf && z ~= Inf)
        %p = normcdf( ( 1 - a*z - z / (norminv(p) - z) ) / ( a + 1 / (norminv(p) - z) ) );
        p = normcdf( ( norminv(p) * (1 - a*z) + z*(a*z - 2) ) / ( 1 + a*norminv(p) - a*z));
    end
    if p < .5
        p = p * 2;
    else
        p = (1 - p) * 2;
    end
end

